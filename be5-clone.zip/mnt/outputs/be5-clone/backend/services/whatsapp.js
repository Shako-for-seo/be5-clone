/**
 * WhatsApp Business Cloud API Service
 * Docs: https://developers.facebook.com/docs/whatsapp/cloud-api
 */
const axios = require('axios');
const { getDb } = require('../database/db');

const WA_API_URL = `https://graph.facebook.com/v19.0/${process.env.WA_PHONE_NUMBER_ID}/messages`;
const HEADERS = () => ({
  'Authorization': `Bearer ${process.env.WA_ACCESS_TOKEN}`,
  'Content-Type': 'application/json',
});

// ===== SEND TEXT MESSAGE =====
async function sendMessage(phone, message, type = 'text') {
  const db = getDb();
  const normalizedPhone = normalizePhone(phone);

  const payload = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: normalizedPhone,
    type: 'text',
    text: { body: message, preview_url: false },
  };

  let waId = null;
  let status = 'sent';

  try {
    const res = await axios.post(WA_API_URL, payload, { headers: HEADERS() });
    waId = res.data?.messages?.[0]?.id;
    console.log(`✅ WhatsApp sent to ${normalizedPhone}: ${waId}`);
  } catch (err) {
    status = 'failed';
    console.error(`❌ WhatsApp send failed to ${normalizedPhone}:`, err.response?.data || err.message);
  }

  // Log the message
  db.prepare(`
    INSERT INTO wa_messages (phone, direction, type, message, wa_id, status)
    VALUES (?, 'outbound', ?, ?, ?, ?)
  `).run(normalizedPhone, type, message, waId, status);

  return { success: status === 'sent', waId };
}

// ===== SEND SURVEY =====
async function sendSurvey(phone, customerName, customQuestion = null) {
  const db = getDb();
  const setting = db.prepare('SELECT value FROM settings WHERE key = ?');
  const question = customQuestion || setting.get('surveyQuestion')?.value || 'როგორ შეაფასებდით ჩვენს მომსახურებას? (1-5)';

  const greeting = customerName ? `გამარჯობა, ${customerName}! 👋\n\n` : 'გამარჯობა! 👋\n\n';
  const message = greeting + question;

  // Create survey record
  let customer = db.prepare('SELECT id FROM customers WHERE phone = ?').get(normalizePhone(phone));
  if (!customer) {
    const res = db.prepare('INSERT INTO customers (phone, name) VALUES (?, ?)').run(normalizePhone(phone), customerName || null);
    customer = { id: res.lastInsertRowid };
  }

  const surveyRes = db.prepare(`
    INSERT INTO surveys (customer_id, phone, customer_name, question, status, type)
    VALUES (?, ?, ?, ?, 'pending', 'satisfaction')
  `).run(customer.id, normalizePhone(phone), customerName || null, question);

  const { success, waId } = await sendMessage(phone, message, 'survey');

  // Update survey with WA message ID
  if (waId) {
    db.prepare('UPDATE surveys SET wa_message_id = ? WHERE id = ?').run(waId, surveyRes.lastInsertRowid);
  }

  return { success, surveyId: surveyRes.lastInsertRowid };
}

// ===== SEND REVIEW REQUEST (for positive respondents) =====
async function sendReviewRequest(phone, customerName) {
  const db = getDb();
  const reviewLink = db.prepare('SELECT value FROM settings WHERE key = ?').get('reviewLink')?.value || process.env.GOOGLE_REVIEW_LINK;
  const businessName = db.prepare('SELECT value FROM settings WHERE key = ?').get('businessName')?.value || 'ჩვენი ბიზნესი';

  const message = `${customerName ? customerName + ', გ' : 'გ'}მადლობთ თქვენი დადებითი შეფასებისთვის! 🙏\n\nგთხოვთ, გაგვიზიარეთ თქვენი შთაბეჭდილება Google-ზეც — ეს დიდ მნიშვნელობას ანიჭებს ${businessName}-ს:\n\n⭐⭐⭐⭐⭐ ${reviewLink}\n\nგმადლობთ! ❤️`;

  return sendMessage(phone, message, 'review_request');
}

// ===== SEND NEGATIVE ALERT TO ADMIN =====
async function notifyAdminNegative(phone, customerName, rating, response) {
  const adminPhone = process.env.ADMIN_WHATSAPP;
  const businessName = process.env.BUSINESS_NAME || 'ბიზნესი';
  if (!adminPhone) return;

  const stars = '⭐'.repeat(rating) + '☆'.repeat(5 - rating);
  const message = `🚨 *ნეგატიური შეფასება!*\n\nბიზნესი: ${businessName}\nმომხმარებელი: ${customerName || 'უცნობი'}\nტელეფონი: ${phone}\nშეფასება: ${stars} (${rating}/5)\nკომენტარი: "${response}"\n\n⚡ სასწრაფოდ დაუკავშირდით!`;

  return sendMessage(adminPhone, message, 'notification');
}

// ===== HANDLE INCOMING WEBHOOK =====
async function handleIncomingMessage(entry) {
  const db = getDb();
  const changes = entry?.changes || [];

  for (const change of changes) {
    const messages = change.value?.messages || [];

    for (const msg of messages) {
      const phone = msg.from;
      const text = msg.text?.body?.trim() || '';
      const timestamp = new Date(parseInt(msg.timestamp) * 1000);

      // Log inbound
      db.prepare(`
        INSERT INTO wa_messages (phone, direction, type, message, wa_id, status)
        VALUES (?, 'inbound', 'response', ?, ?, 'received')
      `).run(phone, text, msg.id);

      // Find pending survey for this phone
      const survey = db.prepare(`
        SELECT * FROM surveys WHERE phone = ? AND status = 'pending'
        ORDER BY created_at DESC LIMIT 1
      `).get(phone);

      if (survey) {
        await processSurveyResponse(survey, phone, text);
      }
    }
  }
}

// ===== PROCESS SURVEY RESPONSE =====
async function processSurveyResponse(survey, phone, text) {
  const db = getDb();
  const setting = db.prepare('SELECT value FROM settings WHERE key = ?');
  const threshold = parseInt(setting.get('negativeThreshold')?.value || '3');

  // Parse rating from message (accept "1"-"5", "⭐"-"⭐⭐⭐⭐⭐", or text)
  let rating = parseRating(text);
  const status = rating !== null ? (rating > threshold ? 'positive' : 'negative') : 'pending';

  db.prepare(`
    UPDATE surveys
    SET response = ?, rating = ?, status = ?, responded_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(text, rating, status, survey.id);

  if (rating === null) {
    // Couldn't parse — ask again
    await sendMessage(phone, 'გთხოვთ, გამოგვიგზავნოთ რიცხვი 1-დან 5-მდე (მაგ: "5" ან "3")', 'survey');
    return;
  }

  const customerName = survey.customer_name;

  if (status === 'positive') {
    // Send review link
    const reviewLinkAlreadySent = survey.review_link_sent;
    if (!reviewLinkAlreadySent) {
      await sendReviewRequest(phone, customerName);
      db.prepare('UPDATE surveys SET review_link_sent = 1 WHERE id = ?').run(survey.id);
    }
  } else {
    // Notify admin of negative review
    await notifyAdminNegative(phone, customerName, rating, text);
    // Send empathy message to customer
    const businessName = process.env.BUSINESS_NAME || 'ჩვენი ბიზნესი';
    await sendMessage(phone, `ძვირფასო${customerName ? ' ' + customerName : ''}! 🙏\n\nბოდიში, რომ ჩვენი მომსახურება ვერ გაამართლა თქვენი მოლოდინი. ${businessName}-ს წარმომადგენელი მალე დაგიკავშირდებათ!\n\nგმადლობთ გულახდილობისთვის. ❤️`, 'text');
  }
}

// ===== BROADCAST =====
async function broadcast(message, phones) {
  const results = [];
  for (const phone of phones) {
    const r = await sendMessage(phone, message, 'broadcast');
    results.push({ phone, ...r });
    // Rate limit: max 1 msg per 200ms
    await new Promise(r => setTimeout(r, 200));
  }
  return results;
}

// ===== HELPERS =====
function normalizePhone(phone) {
  // Ensure E.164 format
  return phone.replace(/[\s\-\(\)]/g, '').replace(/^\+/, '');
}

function parseRating(text) {
  const t = text.trim();
  // Try direct number
  if (/^[1-5]$/.test(t)) return parseInt(t);
  // Try counting stars
  const stars = (t.match(/⭐/g) || []).length;
  if (stars >= 1 && stars <= 5) return stars;
  // Try word matching
  const low = t.toLowerCase();
  if (low.includes('ცუდ') || low.includes('bad')) return 1;
  if (low.includes('კარგ') || low.includes('good')) return 4;
  if (low.includes('შესანი') || low.includes('excellent') || low.includes('perfect')) return 5;
  return null;
}

module.exports = { sendMessage, sendSurvey, sendReviewRequest, notifyAdminNegative, handleIncomingMessage, broadcast };
