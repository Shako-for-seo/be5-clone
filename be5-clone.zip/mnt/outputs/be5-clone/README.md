# Be5 — WhatsApp Review Management System

A full-stack clone of [be5.ge](https://be5.ge) — a WhatsApp-based reputation management platform that helps businesses boost 5-star Google reviews and suppress negative ones.

---

## 🏗 Project Structure

```
be5-clone/
├── frontend/              # Static site → GitHub Pages
│   ├── index.html         # Georgian landing page
│   ├── css/style.css
│   ├── js/main.js
│   └── admin/index.html   # Admin dashboard
│
└── backend/               # Node.js server → Railway / Render / VPS
    ├── server.js           # Main Express app + CRON jobs
    ├── .env.example        # All environment variables
    ├── package.json
    ├── database/
    │   ├── setup.js        # Creates SQLite DB & tables
    │   └── db.js           # DB connection singleton
    ├── routes/
    │   ├── webhook.js      # WhatsApp Cloud API webhook
    │   ├── leads.js        # Lead form API
    │   ├── surveys.js      # Survey management API
    │   ├── reviews.js      # Google reviews API
    │   ├── whatsapp.js     # WhatsApp messaging API
    │   └── dashboard.js    # Dashboard stats API
    └── services/
        ├── whatsapp.js     # WhatsApp Cloud API integration
        ├── googleReviews.js # Google Business Profile API
        └── notifications.js # Email alerts via Nodemailer
```

---

## 🚀 Quick Start

### 1. Clone & Install Backend

```bash
git clone https://github.com/YOUR_USERNAME/be5-clone.git
cd be5-clone/backend
npm install
cp .env.example .env
# Edit .env with your API keys (see below)
npm run setup-db   # Initialize the database
npm run dev        # Start development server
```

### 2. Deploy Frontend to GitHub Pages

```bash
# In GitHub: Settings → Pages → Source: main branch / frontend folder
# OR use gh-pages npm package:
cd frontend
# Update BACKEND_URL in js/main.js and admin/index.html to your backend URL
```

### 3. Update API URL in Frontend

In `frontend/js/main.js` and `frontend/admin/index.html`, change:
```js
const BACKEND_URL = 'http://localhost:3001';
// →
const BACKEND_URL = 'https://your-backend.railway.app';
```

---

## 🔑 Environment Variables

Copy `.env.example` to `.env` and fill in:

### WhatsApp Business Cloud API (Meta)
1. Go to [developers.facebook.com](https://developers.facebook.com)
2. Create an App → Add WhatsApp product
3. Get: `WA_PHONE_NUMBER_ID`, `WA_ACCESS_TOKEN`, `WA_BUSINESS_ACCOUNT_ID`
4. Set webhook URL to: `https://your-backend.com/webhook`
5. Set `WA_VERIFY_TOKEN` to any random string you choose

```env
WA_PHONE_NUMBER_ID=your_phone_number_id
WA_ACCESS_TOKEN=your_permanent_access_token
WA_VERIFY_TOKEN=my_secret_verify_token_123
```

### Google Business Profile API
1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Enable: "My Business Account Management API" and "My Business Information API"
3. Create OAuth 2.0 credentials
4. Get refresh token via OAuth Playground: [developers.google.com/oauthplayground](https://developers.google.com/oauthplayground)
5. Find your `GOOGLE_LOCATION_NAME` via the API: `accounts/{accountId}/locations/{locationId}`

```env
GOOGLE_CLIENT_ID=your_client_id
GOOGLE_CLIENT_SECRET=your_client_secret
GOOGLE_REFRESH_TOKEN=your_refresh_token
GOOGLE_LOCATION_NAME=accounts/123456789/locations/987654321
GOOGLE_REVIEW_LINK=https://g.page/r/YOUR_PLACE_ID/review
```

### Email (Gmail App Password)
1. Enable 2FA on Gmail
2. Go to Google Account → Security → App passwords
3. Generate an app password for "Mail"

```env
SMTP_USER=your@gmail.com
SMTP_PASS=your_16_char_app_password
ADMIN_EMAIL=admin@yourbusiness.ge
ADMIN_WHATSAPP=+995598888817
```

---

## 📡 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET/POST | `/webhook` | WhatsApp Cloud API webhook |
| POST | `/api/leads` | Submit lead from landing page |
| GET | `/api/leads` | List all leads |
| POST | `/api/surveys/send` | Send WhatsApp survey |
| POST | `/api/surveys/bulk` | Bulk send surveys |
| GET | `/api/surveys` | List all surveys |
| GET | `/api/reviews` | List Google reviews |
| POST | `/api/reviews/fetch` | Pull latest from Google API |
| POST | `/api/reviews/:id/reply` | Post reply to a review |
| POST | `/api/reviews/auto-reply-all` | Auto-reply all unanswered |
| POST | `/api/whatsapp/broadcast` | Broadcast message to leads |
| GET | `/api/dashboard/stats` | Dashboard KPIs |
| GET/POST | `/api/settings` | Get/update settings |
| GET | `/health` | Health check |

---

## 🔄 How the Survey Flow Works

```
Customer interaction (purchase / visit)
        ↓
Be5 sends WhatsApp survey to customer
        ↓
Customer replies with rating (1–5)
        ↓
   Rating > threshold?
   ┌──── YES ────┐         ┌──── NO ────┐
   ↓             ↓         ↓            ↓
Send review  Customer  Alert admin   Send empathy
  link →     leaves    instantly!    message to
 Google      5-star               customer, handle
 review!     review               privately
```

---

## ⚙️ Scheduled Jobs (auto-running)

| Schedule | Job |
|----------|-----|
| Every 1 hour | Fetch new Google reviews |
| Every 2 hours | Auto-reply to unanswered Google reviews |
| Every 30 min | Check for new negative reviews → notify admin |

---

## 🌐 Deployment

### Backend: Railway (recommended free tier)
```bash
npm install -g @railway/cli
railway login
railway new
railway up
railway variables set PORT=3001 WA_PHONE_NUMBER_ID=... # add all env vars
```

### Backend: Render
- Connect GitHub repo
- Set Build Command: `cd backend && npm install`
- Set Start Command: `node backend/server.js`
- Add all environment variables in dashboard

### Frontend: GitHub Pages
- Push code to GitHub
- Settings → Pages → Deploy from branch → `main` / `frontend` folder
- Your site will be at: `https://YOUR_USERNAME.github.io/be5-clone/`

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, Vanilla JS |
| Backend | Node.js, Express.js |
| Database | SQLite (better-sqlite3) |
| WhatsApp | Meta WhatsApp Business Cloud API |
| Google | Google Business Profile API (OAuth 2.0) |
| Email | Nodemailer (Gmail SMTP) |
| Cron Jobs | node-cron |
| Hosting (FE) | GitHub Pages |
| Hosting (BE) | Railway / Render / any VPS |

---

## 📄 License

MIT — Built as a clone/study of [be5.ge](https://be5.ge) by WEDOMEDIA.
